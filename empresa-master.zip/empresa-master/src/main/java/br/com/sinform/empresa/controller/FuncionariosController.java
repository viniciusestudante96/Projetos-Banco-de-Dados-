package br.com.sinform.empresa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import br.com.sinform.empresa.model.Cargo;
import br.com.sinform.empresa.model.Funcionario;
import br.com.sinform.empresa.repository.CargosRepository;

@Controller
public class FuncionariosController {

	@Autowired
	private CargosRepository cargosRepository;
	
	@GetMapping("/funcionarios/novo")
	public ModelAndView novo(){
		ModelAndView mv = new ModelAndView ("CadastroFuncionario");
		
		mv.addObject(new Funcionario());
	
		return mv; 
	}
	
	@GetMapping("/funcionarios")
	public String listar(){
		return "ListaFuncionarios";
	}
	
	@ModelAttribute(name="cargos")
	public List<Cargo> cargos(){
		return cargosRepository.findAll();
	}
	
}
