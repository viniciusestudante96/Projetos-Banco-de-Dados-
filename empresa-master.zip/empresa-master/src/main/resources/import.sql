insert into cargos (descricao) values ('Analista de Sistemas');
insert into cargos (descricao) values ('Desenvolvedor Web');
insert into cargos (descricao) values ('Analista de Testes');
insert into cargos (descricao) values ('Gerente de TI');