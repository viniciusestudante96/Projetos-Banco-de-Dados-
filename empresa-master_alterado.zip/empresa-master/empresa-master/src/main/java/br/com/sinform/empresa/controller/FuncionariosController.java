package br.com.sinform.empresa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.sinform.empresa.model.Funcionario;

@Controller
public class FuncionariosController {

	@GetMapping("/funcionarios/novo")
	public ModelAndView novo(){
		ModelAndView mv = new ModelAndView ("CadastroFuncionario");
		
		mv.addObject(new Funcionario());
	
		return mv; 
	}
	
	@GetMapping("/funcionarios")
	public String listar(){
		return "ListaFuncionarios";
	}
	
}
