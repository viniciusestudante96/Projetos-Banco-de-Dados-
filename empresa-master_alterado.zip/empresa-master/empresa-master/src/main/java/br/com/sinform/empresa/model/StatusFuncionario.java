package br.com.sinform.empresa.model;

public enum StatusFuncionario {
	ATIVO, INATIVO;
}
